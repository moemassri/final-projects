package com.varscon.sendcorp.SendCorp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendCorpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SendCorpApplication.class, args);
	}

}
