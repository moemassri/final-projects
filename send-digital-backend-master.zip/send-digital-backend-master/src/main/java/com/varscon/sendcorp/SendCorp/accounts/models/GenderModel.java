package com.varscon.sendcorp.SendCorp.accounts.models;

public enum  GenderModel {
    MALE,
    FEMALE,
    NEUTRAL
}
