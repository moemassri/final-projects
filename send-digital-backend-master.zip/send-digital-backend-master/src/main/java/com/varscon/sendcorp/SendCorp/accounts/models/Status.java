package com.varscon.sendcorp.SendCorp.accounts.models;

public enum Status {
    VERIFICATION_PENDING,
    VERIFIED,
    VERIFICATION_DECLINED,
}
