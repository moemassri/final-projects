package com.varscon.sendcorp.SendCorp.accounts.models;

public enum UserRoleModel {
    USER,
    ADMIN
}
