package com.varscon.sendcorp.SendCorp.notifications;

public class EmailTemplates {
    public static final String WELCOME_EMAIL = "welcome_email";
    public static final String ACTIVITY_NOTICE = "activity_notice";
}
